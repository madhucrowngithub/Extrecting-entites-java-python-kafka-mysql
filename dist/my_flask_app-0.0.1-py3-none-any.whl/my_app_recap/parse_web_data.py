from bs4 import BeautifulSoup


def content_list():

    with open('index.html', 'r') as f:
        contents = f.read()

        soup = BeautifulSoup(contents, "html.parser")

        for child in soup.descendants:

            if child.name:
                print(child.name)

def content_text():
    with open('index.html', 'r') as f:
        contents = f.read()

        soup = BeautifulSoup(contents, "html.parser")
        

        print(soup.h2.text)
        print(soup.p.text)

        
        print(soup.li.text)
    for tag in soup.find_all('li'):
            print(tag.text)

content_list()
content_text()
