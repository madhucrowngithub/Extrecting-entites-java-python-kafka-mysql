from flask import Flask
from flask import render_template
from mdc import MDC
import logging
import json
import uuid

with MDC(name="_root_"):
    logging.info("Logger initialized")

app = Flask(__name__)

@app.route('/recap/getuid')
def get_uid():
    return(uuid.uuid4().hex)

@app.route('/recap/all')
def hello():
    return 'Hello, Flask!'

@app.route('/recap/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(port=4500,debug=True)