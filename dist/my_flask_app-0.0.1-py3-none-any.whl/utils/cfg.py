from config import Config
import os

class Cfg:
    # Remote Logging
    BACKUP_COUNT = 10
    LOG_SIZE = 100
    LOGGING_FILE_PREFIX = 'trace'
    LOGGER_HOST = "localhost"